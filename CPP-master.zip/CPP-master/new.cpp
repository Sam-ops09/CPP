#include<iostream>
int main(int)