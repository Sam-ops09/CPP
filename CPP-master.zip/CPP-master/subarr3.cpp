#include<iostream>
using namespace std;
 
int main()
{
    int x,y,z,result;
    x =  10;
    y= 10;
    z= 15;
    result= !(a>b)
    cout<<result<<endl;
    return 0;
}