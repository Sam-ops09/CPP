#include<iostream>
using namespace std;

int main()
{
    cout << "Hello Guys" << endl;
    return 0;
}