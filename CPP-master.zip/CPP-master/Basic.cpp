#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    int c;
    long ld;
    char ch;
    float f;
    double d;
    cin>>c>>ld>>ch>>f>>d;
    cout<<c<<endl;
    cout<<ld<<endl;
    cout<<ch<<endl;
    cout<<f<<endl;
    cout<<d<<endl;
    return 0;
}