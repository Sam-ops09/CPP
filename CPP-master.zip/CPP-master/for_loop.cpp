#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    int a,b,n;
    a<b;
    cin>>a>>b;
    string words[10]= {"Greater than 9","one","two","three","four","five","six","seven",
    "eight","nine"};
    for (a<=n<=b,1<=n<=9,n++)
    {
        cout<<words[n]<<;
    }
    for(a<=n<=b,n>9,n++){
        if(n%2==0){
            cout<<"even"<<endl;
        }
        else{
            cout<<"odd"<<endl;
        }
    }
    return 0;
}

    